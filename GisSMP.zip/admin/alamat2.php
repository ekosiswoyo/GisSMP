<?php

// Beranda
if ($_GET['pages']=='home'){ 
include "home.php";
}

// pages
else
if ($_GET['pages']=='wisata'){ 
include "pages/wisata/wisata.php";
}
else
if ($_GET['pages']=='wisata_tambah'){ 
include "pages/wisata/wisata_tambah.php";
}
else
if ($_GET['pages']=='wisata_edit'){ 
include "pages/wisata/wisata_edit.php";
}
else
if ($_GET['pages']=='wisata_detail'){ 
include "pages/wisata/wisata_detail.php";
}
else
if ($_GET['pages']=='wisata_hapus'){ 
include "pages/wisata/wisata_hapus.php";
}
else
if ($_GET['pages']=='tambahwisata'){ 
include "pages/wisata/tambahwisata.php";
}
else
if ($_GET['pages']=='editwisata'){ 
include "pages/wisata/editwisata.php";
}
else
if ($_GET['pages']=='wisata_tampilkan'){ 
include "pages/wisata/wisata_tampilkan.php";
}
else
if ($_GET['pages']=='wisata_tarik'){ 
include "pages/wisata/wisata_tarik.php";
}

else
if ($_GET['pages']=='kategorifasum'){ 
include "pages/kategorifasum/kategorifasum.php";
}
else
if ($_GET['pages']=='kategorifasum_tambah'){ 
include "pages/kategorifasum/kategorifasum_tambah.php";
}
else
if ($_GET['pages']=='kategorifasum_edit'){ 
include "pages/kategorifasum/kategorifasum_edit.php";
}
else
if ($_GET['pages']=='kategorifasum_detail'){ 
include "pages/kategorifasum/kategorifasum_detail.php";
}
else
if ($_GET['pages']=='kategorifasum_hapus'){ 
include "pages/kategorifasum/kategorifasum_hapus.php";
}
else
if ($_GET['pages']=='tambahkategorifasum'){ 
include "pages/kategorifasum/tambahkategorifasum.php";
}
else
if ($_GET['pages']=='editkategorifasum'){ 
include "pages/kategorifasum/editkategorifasum.php";
}

else
if ($_GET['pages']=='fasilitasumum'){ 
include "pages/fasilitasumum/fasilitasumum.php";
}
else
if ($_GET['pages']=='fasilitasumum_tambah'){ 
include "pages/fasilitasumum/fasilitasumum_tambah.php";
}
else
if ($_GET['pages']=='fasilitasumum_edit'){ 
include "pages/fasilitasumum/fasilitasumum_edit.php";
}
else
if ($_GET['pages']=='fasilitasumum_detail'){ 
include "pages/fasilitasumum/fasilitasumum_detail.php";
}
else
if ($_GET['pages']=='fasilitasumum_hapus'){ 
include "pages/fasilitasumum/fasilitasumum_hapus.php";
}
else
if ($_GET['pages']=='tambahfasilitasumum'){ 
include "pages/fasilitasumum/tambahfasilitasumum.php";
}
else
if ($_GET['pages']=='editfasilitasumum'){ 
include "pages/fasilitasumum/editfasilitasumum.php";
}

else
if ($_GET['pages']=='hotel'){ 
include "pages/penginapan/hotel.php";
}
else
if ($_GET['pages']=='hotel_tambah'){ 
include "pages/penginapan/hotel_tambah.php";
}
else
if ($_GET['pages']=='hotel_edit'){ 
include "pages/penginapan/hotel_edit.php";
}
else
if ($_GET['pages']=='hotel_detail'){ 
include "pages/penginapan/hotel_detail.php";
}
else
if ($_GET['pages']=='hotel_hapus'){ 
include "pages/penginapan/hotel_hapus.php";
}
else
if ($_GET['pages']=='tambahhotel'){ 
include "pages/penginapan/tambahhotel.php";
}
else
if ($_GET['pages']=='edithotel'){ 
include "pages/penginapan/edithotel.php";
}

else
if ($_GET['pages']=='makan'){ 
include "pages/makan/makan.php";
}
else
if ($_GET['pages']=='makan_tambah'){ 
include "pages/makan/makan_tambah.php";
}
else
if ($_GET['pages']=='makan_edit'){ 
include "pages/makan/makan_edit.php";
}
else
if ($_GET['pages']=='makan_detail'){ 
include "pages/makan/makan_detail.php";
}
else
if ($_GET['pages']=='makan_hapus'){ 
include "pages/makan/makan_hapus.php";
}
else
if ($_GET['pages']=='tambahmakan'){ 
include "pages/makan/tambahmakan.php";
}
else
if ($_GET['pages']=='editmakan'){ 
include "pages/makan/editmakan.php";
}

else
if ($_GET['pages']=='ibadah'){ 
include "pages/ibadah/ibadah.php";
}
else
if ($_GET['pages']=='ibadah_tambah'){ 
include "pages/ibadah/ibadah_tambah.php";
}
else
if ($_GET['pages']=='ibadah_edit'){ 
include "pages/ibadah/ibadah_edit.php";
}
else
if ($_GET['pages']=='ibadah_detail'){ 
include "pages/ibadah/ibadah_detail.php";
}
else
if ($_GET['pages']=='ibadah_hapus'){ 
include "pages/ibadah/ibadah_hapus.php";
}
else
if ($_GET['pages']=='tambahibadah'){ 
include "pages/ibadah/tambahibadah.php";
}
else
if ($_GET['pages']=='editibadah'){ 
include "pages/ibadah/editibadah.php";
}

else
if ($_GET['pages']=='spbu'){ 
include "pages/spbu/spbu.php";
}
else
if ($_GET['pages']=='spbu_tambah'){ 
include "pages/spbu/spbu_tambah.php";
}
else
if ($_GET['pages']=='spbu_edit'){ 
include "pages/spbu/spbu_edit.php";
}
else
if ($_GET['pages']=='spbu_detail'){ 
include "pages/spbu/spbu_detail.php";
}
else
if ($_GET['pages']=='spbu_hapus'){ 
include "pages/spbu/spbu_hapus.php";
}
else
if ($_GET['pages']=='tambahspbu'){ 
include "pages/spbu/tambahspbu.php";
}else
if ($_GET['pages']=='editspbu'){ 
include "pages/spbu/editspbu.php";
}

else
if ($_GET['pages']=='transport'){ 
include "pages/transport/transport.php";
}
else
if ($_GET['pages']=='transport_tambah'){ 
include "pages/transport/transport_tambah.php";
}
else
if ($_GET['pages']=='transport_edit'){ 
include "pages/transport/transport_edit.php";
}
else
if ($_GET['pages']=='transport_detail'){ 
include "pages/transport/transport_detail.php";
}
else
if ($_GET['pages']=='transport_hapus'){ 
include "pages/transport/transport_hapus.php";
}
else
if ($_GET['pages']=='tambahtransport'){ 
include "pages/transport/tambahtransport.php";
}
else
if ($_GET['pages']=='edittransport'){ 
include "pages/transport/edittransport.php";
}

else
if ($_GET['pages']=='standar'){ 
include "pages/standar/standar.php";
}
else
if ($_GET['pages']=='add_standar'){ 
include "pages/standar/add_standar.php";
}
else
if ($_GET['pages']=='edit_standar'){ 
include "pages/standar/edit_standar.php";
}
else
if ($_GET['pages']=='delete_standar'){ 
include "pages/standar/delete_standar.php";
}
else
if ($_GET['pages']=='periode'){ 
include "pages/periode/periode.php";
}
else
if ($_GET['pages']=='add_periode'){ 
include "pages/periode/add_periode.php";
}
else
if ($_GET['pages']=='edit_periode'){ 
include "pages/periode/edit_periode.php";
}
else
if ($_GET['pages']=='delete_periode'){ 
include "pages/periode/delete_periode.php";
}else
if ($_GET['pages']=='detail_kec'){ 
include "pages/kec/detail_kec.php";
}
else
if ($_GET['pages']=='kec'){ 
include "pages/kec/kec.php";
}
else
if ($_GET['pages']=='map_sekolah'){ 
include "pages/sekolah/map_sekolah.php";
}
else
if ($_GET['pages']=='sekolah'){ 
include "pages/sekolah/sekolah.php";
}
else
if ($_GET['pages']=='add_sekolah'){ 
include "pages/sekolah/add_sekolah.php";
}

else
if ($_GET['pages']=='edit_sekolah'){ 
include "pages/sekolah/edit_sekolah.php";
}
else
if ($_GET['pages']=='delete_sekolah'){ 
include "pages/sekolah/delete_sekolah.php";
}
else
if ($_GET['pages']=='detail_sekolah'){ 
include "pages/sekolah/detail_sekolah.php";
}
else
if ($_GET['pages']=='profil'){ 
include "pages/profil/profil.php";
}
else
if ($_GET['pages']=='edit_profil'){ 
include "pages/profil/edit_profil.php";
}
else
if ($_GET['pages']=='rata_rata'){ 
include "pages/nilaissn/rata_rata.php";
}
else
if ($_GET['pages']=='nilaissn'){ 
include "pages/nilaissn/nilaissn.php";
}
else
if ($_GET['pages']=='add_nilaissn'){ 
include "pages/nilaissn/add_nilaissn.php";
}
else
if ($_GET['pages']=='delete_nilaissn'){ 
include "pages/nilaissn/delete_nilaissn.php";
}
else
if ($_GET['pages']=='detail_nilaissn'){ 
include "pages/nilaissn/detail_nilaissn.php";
}

else
if ($_GET['pages']=='edit_nilaissn'){ 
include "pages/nilaissn/edit_nilaissn.php";
}
else
if ($_GET['pages']=='pesan_edit'){ 
include "pages/pesan/pesan_edit.php";
}
else
if ($_GET['pages']=='editpesan'){ 
include "pages/pesan/editpesan.php";
}
else
if ($_GET['pages']=='pesan_notif'){ 
include "pages/pesan/pesan_notif.php";
}
else
if ($_GET['pages']=='pesan_tampilkan'){ 
include "pages/pesan/pesan_tampilkan.php";
}
else
if ($_GET['pages']=='pesan_hapus'){ 
include "pages/pesan/pesan_hapus.php";
}else
if ($_GET['pages']=='pesan_tarik'){ 
include "pages/pesan/pesan_tarik.php";
}

else
if ($_GET['pages']=='user'){ 
include "pages/user.php";
}
else
if ($_GET['pages']=='admin_edit'){ 
include "pages/admin/admin_edit.php";
}
else
if ($_GET['pages']=='editadmin'){ 
include "pages/admin/editadmin.php";
}
else
if ($_GET['pages']=='profil_edit'){ 
include "pages/profil/profil_edit.php";
}else
if ($_GET['pages']=='editprofil'){ 
include "pages/profil/editprofil.php";
}
else
if ($_GET['pages']=='foto'){ 
include "pages/wisata/foto_edit.php";
}
else
if ($_GET['pages']=='foto2'){ 
include "pages/wisata/foto_edit2.php";
}
else
if ($_GET['pages']=='foto3'){ 
include "pages/wisata/foto_edit3.php";
}
else
if ($_GET['pages']=='foto4'){ 
include "pages/wisata/foto_edit4.php";
}
else
if ($_GET['pages']=='foto5'){ 
include "pages/wisata/foto_edit5.php";
}
else
if ($_GET['pages']=='editfoto'){ 
include "pages/wisata/editfoto.php";
}
else{
include "404.php";	
}
?>