﻿

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">

            </div>

            <!-- Widgets -->
           <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        <?php
                        $level=$_SESSION['level'];
                        
                        ?>
                            <h2>
                               Selamat Datang, <?php echo $level; ?> !</a></small>
                            </h2>
                          
                        </div>
                        <div class="body">
                            
                        <div id="map" style="width:auto; height:500px;"></div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Widgets -->
           
            </div>
        </div>
    </section>